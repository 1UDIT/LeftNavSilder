import React from "react";

const Header =()=>{
    return(
        <div className="Header"><p>Header</p></div>
    )
}
export default Header;