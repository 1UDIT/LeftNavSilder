const  GVG_workFlow = [

    {
        name: "Filename  "
    },
    {
        name: "Category(PTI/AP)"

    },
    {
        name: "Datetime"

    },
    {
        name: "CompletedDate"

    },
    {
        name: "AssetId"

    },
    {
        name: "DomainId"

    },
    {
        name: "status"

    },
    {
        name: "Error Details"

    },

]
export default GVG_workFlow;