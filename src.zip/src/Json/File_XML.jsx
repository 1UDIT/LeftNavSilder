const  XLM = [

    {
        name: " Filename   "
    },
    {
        name: "pathreadFrom"

    },
    {
        name: "Datetime"

    },
    {
        name: "State"

    },
    {
        name: "Error Details"

    }
]
export default XLM;