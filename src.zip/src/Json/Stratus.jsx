const  GVG_Stratus_Rundown = [

    {
        name: "Request ID "
    },
    {
        name: "Rundown Name"

    },
    {
        name: "Submisson Date"

    },
    {
        name: "XMLfilename"

    },
    {
        name: "Creation time"

    },
    {
        name: "State"

    },
    {
        name: "Error Details"

    },

]
export default GVG_Stratus_Rundown;