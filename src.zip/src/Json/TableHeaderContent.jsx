const TableHeaderContent = [

    {
        name: "Request ID"
    },
    {
        name: "Asset Name"

    },
    {
        name: "assetID"

    },
    {
        name: "Domainid"

    },
    {
        name: "SubmissionDate"

    },
    {
        name: "PlaceholderName"

    },
    {
        name: "PlaceholderCreatedTDate"

    },
    {
        name: "Modfied"

    },
    {
        name: "Name"

    },
    
    {
        name: "ModifiedDate"

    },
    
    {
        name: "status"

    },
    {
        name: " Error Details"

    },
   
]
export default TableHeaderContent;